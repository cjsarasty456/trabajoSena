package com.sena.jwt.model.security;

public enum role {
    Admin,
    User

}
