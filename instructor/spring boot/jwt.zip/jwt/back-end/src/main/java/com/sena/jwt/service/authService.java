package com.sena.jwt.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.sena.jwt.interfaceService.IUserServices;
import com.sena.jwt.interfaces.IUser;
import com.sena.jwt.model.security.authResponse;
import com.sena.jwt.model.security.loginRequest;
import com.sena.jwt.model.security.registerRequest;
import com.sena.jwt.model.security.role;
import com.sena.jwt.model.security.user;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class authService implements IUserServices  {

    final IUser data;
    //private final jwtService

    public authResponse register(registerRequest request){
        user userData=user.builder()
            .first_name(request.getFirstName())
            .last_name(request.getLastName())
            .role(role.User)
            .user_name(request.getUserName())
            .password(request.getPassword())
            .build();
        
        data.save(userData);
        return authResponse.builder()
        .token(null)
        .build();
    }

    public authResponse login(loginRequest request){
        return new authResponse();
    }

 

    @Override
    public Optional<user> findByUsername(String userName) {
        // TODO Auto-generated method stub
        return null;
       // throw new UnsupportedOperationException("Unimplemented method 'findByUsername'");
    }

    @Override
    public int delete(String id) {
        // TODO Auto-generated method stub
        return 0;
    }

    @Override
    public List<user> findAll() {
        // TODO Auto-generated method stub
        return null;
        //throw new UnsupportedOperationException("Unimplemented method 'findAll'");
    }

}
