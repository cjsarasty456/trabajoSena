package com.sena.crud_basic;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudBasicApplication {

		public static void main(String[] args) {
		SpringApplication.run(CrudBasicApplication.class, args);
	}

}
