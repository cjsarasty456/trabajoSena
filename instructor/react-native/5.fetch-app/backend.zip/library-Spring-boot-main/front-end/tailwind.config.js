/** @type {import('tailwindcss').Config} */
export default {
    theme: {
      extend: {
        fontFamily: {
          jacques: ['"Jacques Francois"', "serif"], // Asegúrate de poner comillas dobles
        },
      },
    },
    plugins: [],
  };